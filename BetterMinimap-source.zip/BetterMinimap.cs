using System.Collections.Generic;
using System.IO;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using BepInEx;

namespace BetterMinimap
{
    /// <summary>
    /// MonoBehaviour controller for BetterMinimap.
    /// Handles:
    /// - Always-moveable minimap (no edit mode required)
    /// - Resize toggle between small and large
    /// - Position/size persistence
    /// - Area map overlay with scene maps
    /// </summary>
    public class BetterMinimapController : MonoBehaviour
    {
        public static BetterMinimapController Instance { get; private set; }

        // Minimap references (found at runtime)
        private Minimap minimapComponent;
        private RectTransform minimapParent;
        private GameObject dragHandle;
        private GameObject centerDragOverlay;

        // Drag state
        private bool isDragging;
        private Vector2 dragOffset;
        private bool initialized;
        private bool minimapButtonHooked;

        // Area Map state
        private bool areaMapOpen;
        private GameObject areaMapCanvas;
        private RawImage areaMapImage;
        private Button worldMapButton;
        private Button closeButton;
        private Text toggleButtonText;
        private Text noAreaMapText; // "No area map available" message
        private bool showingWorldMap;
        private RectTransform areaMapPanelRect; // For dragging
        private bool areaMapDragging;
        private Vector2 areaMapDragOffset;

        // Lock North tracking
        private bool lastLockNorthValue;

        // Center drag tracking (uses pointer events, not drag events)
        private bool centerDragging;
        private Vector2 centerDragStartMousePos;
        private Vector2 centerDragStartMinimapPos;
        private bool lockNorthInitialized;

        // Public property for Harmony patch to check
        public bool IsAreaMapOpen => areaMapOpen;

        // Area map textures
        private string mapAssetsPath;
        private Dictionary<string, Texture2D> mapCache = new Dictionary<string, Texture2D>();
        private List<string> mapAreas = new List<string>
        {
            "Azure", "Azynthi", "AzynthiClear", "Blight", "Brake", "Braxonian",
            "Duskenlight", "FernallaField", "Hidden", "Loomingwood",
            "Malaroth", "Ripper", "SaltedStrand", "ShiveringStep", "ShiveringTomb",
            "Silkengrass", "Soluna", "Stowaway", "Tutorial", "Vitheo",
            "Windwashed"
        };

        /// <summary>
        /// Check if we have an area map for the given scene name.
        /// </summary>
        public bool HasAreaMapForScene(string sceneName)
        {
            return mapAreas.Contains(sceneName);
        }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            // Get the plugin folder from the DLL location (works with versioned folder names like "BetterMinimap-v1.0.3")
            string dllPath = Assembly.GetExecutingAssembly().Location;
            string pluginFolder = Path.GetDirectoryName(dllPath);
            mapAssetsPath = Path.Combine(pluginFolder, "Assets");
            SceneManager.sceneLoaded += OnSceneLoaded;
            Debug.Log("BetterMinimapController: Initialized");
        }

        private void OnDestroy()
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            // Reset references - they may be stale after scene load
            initialized = false;
            minimapComponent = null;
            minimapParent = null;
            minimapButtonHooked = false;

            if (scene.name == "Menu" || scene.name == "LoadScene")
                return;

            // Close area map on scene change
            if (areaMapOpen)
                CloseAreaMap();
        }

        private void FindMinimapReferences()
        {
            if (initialized) return;

            // Find the Minimap component
            minimapComponent = FindObjectOfType<Minimap>();
            if (minimapComponent == null) return;

            minimapParent = minimapComponent.MapPar;
            if (minimapParent == null) return;

            // Apply saved position
            Vector2 savedPos = new Vector2(Plugin.MinimapPosX.Value, Plugin.MinimapPosY.Value);
            minimapParent.localPosition = savedPos;

            // Apply saved size mode
            if (Plugin.MinimapIsBig.Value)
            {
                SetMinimapSize(true);
            }

            // Create drag handle (the blue diamond below the minimap)
            CreateDragHandle();

            // Create center-click drag overlay inside the Mask
            CreateCenterDragOverlay();

            initialized = true;
            Debug.Log("BetterMinimapController: Minimap references found");
        }

        private void CreateDragHandle()
        {
            if (dragHandle != null || minimapComponent == null || minimapParent == null) return;

            // Create a diamond-shaped drag handle centered below the minimap
            dragHandle = new GameObject("DragHandle");
            dragHandle.transform.SetParent(minimapParent, false);

            RectTransform handleRect = dragHandle.AddComponent<RectTransform>();
            // Position centered below the minimap
            float currentSize = minimapComponent.Mask.sizeDelta.x;
            handleRect.anchorMin = new Vector2(0.5f, 0.5f);
            handleRect.anchorMax = new Vector2(0.5f, 0.5f);
            handleRect.pivot = new Vector2(0.5f, 0.5f);
            // Place just below the minimap circle
            handleRect.anchoredPosition = new Vector2(0f, -(currentSize / 2f) - 15f);
            handleRect.sizeDelta = new Vector2(16f, 16f);

            Image handleImage = dragHandle.AddComponent<Image>();
            handleImage.color = new Color32(108, 194, 255, 255); // Same blue as BetterStatsPage

            // Rotate 45 degrees to make it a diamond
            dragHandle.transform.rotation = Quaternion.Euler(0f, 0f, 45f);

            // Add EventTrigger for drag events
            EventTrigger et = dragHandle.AddComponent<EventTrigger>();
            AddDragEvents(et);
        }

        /// <summary>
        /// Creates a transparent overlay inside the Mask that allows dragging the minimap
        /// by clicking anywhere inside the circular map area.
        /// </summary>
        private void CreateCenterDragOverlay()
        {
            if (centerDragOverlay != null || minimapComponent == null || minimapComponent.Mask == null) return;

            // Create overlay as child of Mask so it's inside the circular area
            centerDragOverlay = new GameObject("CenterDragOverlay");
            centerDragOverlay.transform.SetParent(minimapComponent.Mask.transform, false);

            RectTransform overlayRect = centerDragOverlay.AddComponent<RectTransform>();
            // Stretch to fill the Mask completely
            overlayRect.anchorMin = Vector2.zero;
            overlayRect.anchorMax = Vector2.one;
            overlayRect.offsetMin = Vector2.zero;
            overlayRect.offsetMax = Vector2.zero;

            // Make it the last sibling so it's on top of all Mask's children
            centerDragOverlay.transform.SetAsLastSibling();

            // Add transparent Image for raycast
            Image overlayImage = centerDragOverlay.AddComponent<Image>();
            overlayImage.color = new Color(0, 0, 0, 0); // Fully transparent
            overlayImage.raycastTarget = true;

            // Use PointerDown/PointerUp instead of drag events (drag events require threshold)
            EventTrigger et = centerDragOverlay.AddComponent<EventTrigger>();
            AddCenterDragEvents(et);

            Debug.Log("BetterMinimapController: Created center drag overlay");
        }

        private void AddCenterDragEvents(EventTrigger et)
        {
            // Pointer down - start tracking
            EventTrigger.Entry pointerDown = new EventTrigger.Entry { eventID = EventTriggerType.PointerDown };
            pointerDown.callback.AddListener((data) =>
            {
                centerDragging = true;
                GameData.DraggingUIElement = true;
                centerDragStartMousePos = Input.mousePosition;
                centerDragStartMinimapPos = minimapParent.anchoredPosition;
            });
            et.triggers.Add(pointerDown);

            // Pointer up - stop tracking
            EventTrigger.Entry pointerUp = new EventTrigger.Entry { eventID = EventTriggerType.PointerUp };
            pointerUp.callback.AddListener((data) =>
            {
                if (centerDragging)
                {
                    centerDragging = false;
                    GameData.DraggingUIElement = false;
                    SaveMinimapPosition();
                }
            });
            et.triggers.Add(pointerUp);
        }

        private void UpdateCenterDrag()
        {
            if (!centerDragging) return;

            // If mouse button released (safety check)
            if (!Input.GetMouseButton(0))
            {
                centerDragging = false;
                GameData.DraggingUIElement = false;
                SaveMinimapPosition();
                return;
            }

            // Calculate delta and move minimap
            Canvas canvas = minimapParent.GetComponentInParent<Canvas>();
            if (canvas != null)
            {
                Vector2 mouseDelta = (Vector2)Input.mousePosition - centerDragStartMousePos;
                Vector2 scaledDelta = mouseDelta / canvas.scaleFactor;
                minimapParent.anchoredPosition = centerDragStartMinimapPos + scaledDelta;
            }
        }

        private void AddDragEvents(EventTrigger et)
        {
            // Begin drag
            EventTrigger.Entry beginDrag = new EventTrigger.Entry { eventID = EventTriggerType.BeginDrag };
            beginDrag.callback.AddListener((data) =>
            {
                isDragging = true;
                GameData.DraggingUIElement = true;
                PointerEventData pData = (PointerEventData)data;
                Canvas canvas = minimapParent.GetComponentInParent<Canvas>();
                if (canvas != null)
                {
                    Vector2 localPoint;
                    RectTransformUtility.ScreenPointToLocalPointInRectangle(
                        canvas.transform as RectTransform, pData.position, null, out localPoint);
                    dragOffset = (Vector2)minimapParent.localPosition - localPoint;
                }
            });
            et.triggers.Add(beginDrag);

            // Drag
            EventTrigger.Entry drag = new EventTrigger.Entry { eventID = EventTriggerType.Drag };
            drag.callback.AddListener((data) =>
            {
                if (isDragging)
                {
                    PointerEventData pData = (PointerEventData)data;
                    Canvas canvas = minimapParent.GetComponentInParent<Canvas>();
                    if (canvas != null)
                    {
                        Vector2 localPoint;
                        RectTransformUtility.ScreenPointToLocalPointInRectangle(
                            canvas.transform as RectTransform, pData.position, null, out localPoint);
                        minimapParent.localPosition = localPoint + dragOffset;
                    }
                }
            });
            et.triggers.Add(drag);

            // End drag
            EventTrigger.Entry endDrag = new EventTrigger.Entry { eventID = EventTriggerType.EndDrag };
            endDrag.callback.AddListener((data) =>
            {
                isDragging = false;
                GameData.DraggingUIElement = false;
                SaveMinimapPosition();
            });
            et.triggers.Add(endDrag);
        }

        private void UpdateDragHandlePosition()
        {
            if (dragHandle == null || minimapComponent == null) return;
            RectTransform handleRect = dragHandle.GetComponent<RectTransform>();
            float currentSize = minimapComponent.Mask.sizeDelta.x;
            handleRect.anchoredPosition = new Vector2(0f, -(currentSize / 2f) - 15f);
        }

        private void ToggleMinimapSize()
        {
            bool newSize = !Plugin.MinimapIsBig.Value;
            SetMinimapSize(newSize);
            Plugin.MinimapIsBig.Value = newSize;
            Plugin.Instance.SaveConfig();
            UpdateDragHandlePosition();
        }

        private void SetMinimapSize(bool big)
        {
            if (minimapComponent == null) return;

            // Use reflection or direct field access based on Minimap.cs analysis
            if (big)
            {
                minimapComponent.MapCam.orthographicSize = 250f;
                minimapComponent.Mask.sizeDelta = new Vector2(750f, 750f);
                minimapComponent.CircleTrim.sizeDelta = new Vector2(772f, 772f);
                minimapComponent.Buttons.transform.localPosition = new Vector2(
                    minimapComponent.Buttons.transform.localPosition.x, -360f);
                if (minimapComponent.UIDrag != null)
                    minimapComponent.UIDrag.GetComponent<Image>().enabled = false;
            }
            else
            {
                minimapComponent.MapCam.orthographicSize = 100f;
                minimapComponent.Mask.sizeDelta = new Vector2(250f, 250f);
                minimapComponent.CircleTrim.sizeDelta = new Vector2(257f, 256f);
                minimapComponent.Buttons.transform.localPosition = new Vector2(
                    minimapComponent.Buttons.transform.localPosition.x, -100f);
                if (minimapComponent.UIDrag != null)
                    minimapComponent.UIDrag.GetComponent<Image>().enabled = true;
            }
        }

        private void Update()
        {
            // Skip if in menus
            string sceneName = SceneManager.GetActiveScene().name;
            if (sceneName == "Menu" || sceneName == "LoadScene") return;
            if (GameData.PlayerControl == null) return;

            // Find minimap references if not yet found
            FindMinimapReferences();

            // Track and persist Lock North setting
            TrackLockNorthSetting();

            // Handle area map key (M key by default)
            if (Input.GetKeyDown(Plugin.AreaMapKey.Value) && !GameData.PlayerTyping)
            {
                if (areaMapOpen)
                    CloseAreaMap();
                else
                    OpenAreaMap();
            }

            // Hook the minimap's M button if not already done
            HookMinimapButton();

            // Handle right-click on minimap buttons to toggle size
            HandleMinimapRightClick();

            // Handle area map dragging (mouse position polling)
            UpdateAreaMapDrag();

            // Handle minimap center dragging (mouse position polling)
            UpdateCenterDrag();
        }

        private void TrackLockNorthSetting()
        {
            if (minimapComponent == null) return;

            // Initialize lock north on first run - restore saved value
            if (!lockNorthInitialized)
            {
                minimapComponent.LockNorth = Plugin.LockNorth.Value;
                lastLockNorthValue = Plugin.LockNorth.Value;
                lockNorthInitialized = true;
                Debug.Log($"[BetterMinimap] Restored Lock North setting: {Plugin.LockNorth.Value}");
            }

            // Detect when user toggles the lock north button
            if (minimapComponent.LockNorth != lastLockNorthValue)
            {
                lastLockNorthValue = minimapComponent.LockNorth;
                Plugin.LockNorth.Value = minimapComponent.LockNorth;
                Plugin.Instance.SaveConfig();
                Debug.Log($"[BetterMinimap] Saved Lock North setting: {minimapComponent.LockNorth}");
            }
        }

        private void HandleMinimapRightClick()
        {
            if (minimapComponent == null || minimapComponent.Buttons == null) return;

            // Check for right-click
            if (Input.GetMouseButtonDown(1))
            {
                Vector2 mousePos = Input.mousePosition;

                // Check if over any minimap button (the + and - zoom buttons)
                Button[] buttons = minimapComponent.Buttons.GetComponentsInChildren<Button>();
                foreach (Button btn in buttons)
                {
                    RectTransform btnRect = btn.GetComponent<RectTransform>();
                    if (RectTransformUtility.RectangleContainsScreenPoint(btnRect, mousePos))
                    {
                        // Right-clicked on a minimap button - toggle size
                        ToggleMinimapSize();
                        return;
                    }
                }
            }
        }

        private void SaveMinimapPosition()
        {
            if (minimapParent == null) return;
            Plugin.MinimapPosX.Value = minimapParent.localPosition.x;
            Plugin.MinimapPosY.Value = minimapParent.localPosition.y;
            Plugin.Instance.SaveConfig();
        }

        private void HookMinimapButton()
        {
            if (minimapButtonHooked || minimapComponent == null || minimapComponent.Buttons == null) return;

            // Find the M button on the minimap (should be labeled "M" or similar)
            Button[] buttons = minimapComponent.Buttons.GetComponentsInChildren<Button>(true);
            foreach (Button btn in buttons)
            {
                // Check button's text child for "M" label
                Text btnText = btn.GetComponentInChildren<Text>();
                if (btnText != null && btnText.text.Trim().ToUpper() == "M")
                {
                    ReplaceButtonHandler(btn);
                    Debug.Log("[BetterMinimap] Hooked minimap M button");
                    minimapButtonHooked = true;
                    return;
                }
            }

            // If we didn't find by text, try by name
            foreach (Button btn in buttons)
            {
                if (btn.gameObject.name.ToLower().Contains("map") ||
                    btn.gameObject.name.ToLower() == "m")
                {
                    ReplaceButtonHandler(btn);
                    Debug.Log($"[BetterMinimap] Hooked minimap button by name: {btn.gameObject.name}");
                    minimapButtonHooked = true;
                    return;
                }
            }
        }

        private void ReplaceButtonHandler(Button btn)
        {
            // Disable the Button component entirely to prevent its onClick from firing
            // This also disables any persistent listeners set in the Unity Editor
            btn.enabled = false;

            // Add an EventTrigger to handle clicks ourselves
            EventTrigger trigger = btn.gameObject.GetComponent<EventTrigger>();
            if (trigger == null)
                trigger = btn.gameObject.AddComponent<EventTrigger>();

            // Clear any existing triggers
            trigger.triggers.Clear();

            // Add our click handler
            EventTrigger.Entry clickEntry = new EventTrigger.Entry();
            clickEntry.eventID = EventTriggerType.PointerClick;
            clickEntry.callback.AddListener((data) =>
            {
                if (areaMapOpen)
                    CloseAreaMap();
                else
                    OpenAreaMap();
            });
            trigger.triggers.Add(clickEntry);
        }

        #region Area Map

        private void OpenAreaMap()
        {
            if (areaMapOpen) return;

            string sceneName = SceneManager.GetActiveScene().name;
            Debug.Log($"[BetterMinimap] OpenAreaMap called. Scene: {sceneName}");

            CreateAreaMapUI();

            // Load area map if available, otherwise show world map
            if (mapAreas.Contains(sceneName))
            {
                LoadAreaMap(sceneName);
                showingWorldMap = false;
                Debug.Log($"[BetterMinimap] Area map opened for: {sceneName}");
            }
            else
            {
                // No area map for this zone - show world map instead
                LoadAreaMap("MapRoutes");
                showingWorldMap = true;
                Debug.Log($"[BetterMinimap] No area map for scene: {sceneName}, showing world map");
            }

            UpdateToggleButtonText();
            areaMapOpen = true;
        }

        private void CloseAreaMap()
        {
            if (areaMapCanvas != null)
            {
                Destroy(areaMapCanvas);
                areaMapCanvas = null;
            }
            areaMapOpen = false;
            GameData.DraggingUIElement = false; // Allow game input again
        }

        private void CreateAreaMapUI()
        {
            if (areaMapCanvas != null) return;

            // Block game input while area map is open
            GameData.DraggingUIElement = true;

            // Create canvas
            areaMapCanvas = new GameObject("AreaMapCanvas");
            Canvas canvas = areaMapCanvas.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 100;
            areaMapCanvas.AddComponent<CanvasScaler>();
            areaMapCanvas.AddComponent<GraphicRaycaster>();

            // Create fullscreen blocker to catch all clicks
            GameObject blocker = new GameObject("Blocker");
            blocker.transform.SetParent(areaMapCanvas.transform, false);
            RectTransform blockerRect = blocker.AddComponent<RectTransform>();
            blockerRect.anchorMin = Vector2.zero;
            blockerRect.anchorMax = Vector2.one;
            blockerRect.offsetMin = Vector2.zero;
            blockerRect.offsetMax = Vector2.zero;
            Image blockerImg = blocker.AddComponent<Image>();
            blockerImg.color = new Color(0f, 0f, 0f, 0.5f); // Semi-transparent dark background

            // Create centered square panel (use fixed size like the game's world map)
            GameObject panel = new GameObject("Panel");
            panel.transform.SetParent(areaMapCanvas.transform, false);
            RectTransform panelRect = panel.AddComponent<RectTransform>();
            panelRect.anchorMin = new Vector2(0.5f, 0.5f);
            panelRect.anchorMax = new Vector2(0.5f, 0.5f);
            panelRect.pivot = new Vector2(0.5f, 0.5f);
            // Use a fixed square size similar to the game's world map (approximately 700x700)
            panelRect.sizeDelta = new Vector2(700f, 750f);

            Image panelBg = panel.AddComponent<Image>();
            panelBg.color = new Color(0.05f, 0.1f, 0.15f, 0.95f);

            // Store panel rect for dragging
            areaMapPanelRect = panelRect;

            // Restore saved position if available
            if (!float.IsNaN(Plugin.AreaMapPosX.Value) && !float.IsNaN(Plugin.AreaMapPosY.Value))
            {
                panelRect.anchoredPosition = new Vector2(Plugin.AreaMapPosX.Value, Plugin.AreaMapPosY.Value);
            }

            // Add drag support to the panel
            AddAreaMapDragEvents(panel);

            // Create map image - maintain square aspect ratio
            GameObject mapObj = new GameObject("MapImage");
            mapObj.transform.SetParent(panel.transform, false);
            RectTransform mapRect = mapObj.AddComponent<RectTransform>();
            mapRect.anchorMin = new Vector2(0.5f, 0.55f);
            mapRect.anchorMax = new Vector2(0.5f, 0.55f);
            mapRect.pivot = new Vector2(0.5f, 0.5f);
            // Square map image
            mapRect.sizeDelta = new Vector2(650f, 650f);

            areaMapImage = mapObj.AddComponent<RawImage>();
            areaMapImage.color = Color.white;

            // Create toggle button (World Map / Area Map)
            CreateAreaMapButton(panel.transform, "ToggleBtn", "World Map",
                new Vector2(-100f, -340f), new Vector2(150f, 35f),
                ToggleAreaWorldMap, out worldMapButton, out toggleButtonText);

            // Create close button - when no area map, center it
            Text closeText;
            CreateAreaMapButton(panel.transform, "CloseBtn", "Close",
                new Vector2(100f, -340f), new Vector2(150f, 35f),
                CloseAreaMap, out closeButton, out closeText);

            // Create "No area map available" text (hidden by default)
            GameObject noAreaMapObj = new GameObject("NoAreaMapText");
            noAreaMapObj.transform.SetParent(panel.transform, false);
            RectTransform noAreaMapRect = noAreaMapObj.AddComponent<RectTransform>();
            noAreaMapRect.anchorMin = new Vector2(0.5f, 0.5f);
            noAreaMapRect.anchorMax = new Vector2(0.5f, 0.5f);
            noAreaMapRect.pivot = new Vector2(0.5f, 0.5f);
            noAreaMapRect.anchoredPosition = new Vector2(0f, -340f);
            noAreaMapRect.sizeDelta = new Vector2(300f, 35f);

            noAreaMapText = noAreaMapObj.AddComponent<Text>();
            noAreaMapText.text = "No area map available";
            noAreaMapText.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            noAreaMapText.fontSize = 18;
            noAreaMapText.alignment = TextAnchor.MiddleCenter;
            noAreaMapText.color = new Color(0.8f, 0.8f, 0.5f, 1f); // Yellowish
            noAreaMapText.raycastTarget = false;
            noAreaMapObj.SetActive(false); // Hidden by default
        }

        private void CreateAreaMapButton(Transform parent, string name, string text,
            Vector2 position, Vector2 size, UnityEngine.Events.UnityAction onClick,
            out Button btn, out Text txtComp)
        {
            GameObject btnObj = new GameObject(name);
            btnObj.transform.SetParent(parent, false);

            RectTransform btnRect = btnObj.AddComponent<RectTransform>();
            btnRect.anchorMin = new Vector2(0.5f, 0.5f);
            btnRect.anchorMax = new Vector2(0.5f, 0.5f);
            btnRect.pivot = new Vector2(0.5f, 0.5f);
            btnRect.anchoredPosition = position;
            btnRect.sizeDelta = size;

            Image btnImage = btnObj.AddComponent<Image>();
            btnImage.color = new Color(0.2f, 0.4f, 0.6f, 1f);

            btn = btnObj.AddComponent<Button>();
            btn.onClick.AddListener(onClick);

            // Button text
            GameObject textObj = new GameObject("Text");
            textObj.transform.SetParent(btnObj.transform, false);
            RectTransform textRect = textObj.AddComponent<RectTransform>();
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.offsetMin = Vector2.zero;
            textRect.offsetMax = Vector2.zero;

            txtComp = textObj.AddComponent<Text>();
            txtComp.text = text;
            txtComp.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            txtComp.fontSize = 20;
            txtComp.alignment = TextAnchor.MiddleCenter;
            txtComp.color = Color.white;
            txtComp.raycastTarget = false;
        }

        private void AddAreaMapDragEvents(GameObject panel)
        {
            EventTrigger et = panel.GetComponent<EventTrigger>();
            if (et == null)
                et = panel.AddComponent<EventTrigger>();

            // Use PointerDown instead of BeginDrag (no drag threshold needed)
            EventTrigger.Entry pointerDown = new EventTrigger.Entry { eventID = EventTriggerType.PointerDown };
            pointerDown.callback.AddListener((data) =>
            {
                PointerEventData pData = (PointerEventData)data;
                if (pData.button != PointerEventData.InputButton.Left) return;

                areaMapDragging = true;
                Canvas canvas = areaMapCanvas.GetComponent<Canvas>();
                if (canvas != null)
                {
                    RectTransformUtility.ScreenPointToLocalPointInRectangle(
                        canvas.transform as RectTransform, pData.position, null, out Vector2 localPoint);
                    areaMapDragOffset = areaMapPanelRect.anchoredPosition - localPoint;
                }
            });
            et.triggers.Add(pointerDown);

            // Use PointerUp to end dragging
            EventTrigger.Entry pointerUp = new EventTrigger.Entry { eventID = EventTriggerType.PointerUp };
            pointerUp.callback.AddListener((data) =>
            {
                if (!areaMapDragging) return;
                areaMapDragging = false;
                SaveAreaMapPosition();
            });
            et.triggers.Add(pointerUp);
        }

        /// <summary>
        /// Called in Update to handle area map dragging using mouse position polling.
        /// </summary>
        private void UpdateAreaMapDrag()
        {
            if (!areaMapDragging || areaMapPanelRect == null || areaMapCanvas == null) return;

            Canvas canvas = areaMapCanvas.GetComponent<Canvas>();
            if (canvas != null)
            {
                RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    canvas.transform as RectTransform, Input.mousePosition, null, out Vector2 localPoint);
                areaMapPanelRect.anchoredPosition = localPoint + areaMapDragOffset;
            }
        }

        private void SaveAreaMapPosition()
        {
            if (areaMapPanelRect == null) return;
            Plugin.AreaMapPosX.Value = areaMapPanelRect.anchoredPosition.x;
            Plugin.AreaMapPosY.Value = areaMapPanelRect.anchoredPosition.y;
            Plugin.Instance.SaveConfig();
            Debug.Log($"[BetterMinimap] Saved Area Map position: ({Plugin.AreaMapPosX.Value}, {Plugin.AreaMapPosY.Value})");
        }

        private void ToggleAreaWorldMap()
        {
            string sceneName = SceneManager.GetActiveScene().name;

            if (showingWorldMap)
            {
                // Switch to area map if available
                if (mapAreas.Contains(sceneName))
                {
                    LoadAreaMap(sceneName);
                    showingWorldMap = false;
                }
            }
            else
            {
                // Switch to world map
                LoadAreaMap("MapRoutes");
                showingWorldMap = true;
            }

            UpdateToggleButtonText();
        }

        private void UpdateToggleButtonText()
        {
            if (toggleButtonText == null) return;

            string sceneName = SceneManager.GetActiveScene().name;
            bool hasAreaMap = mapAreas.Contains(sceneName);

            if (showingWorldMap && hasAreaMap)
            {
                // Showing world map but area map is available - show toggle button
                toggleButtonText.text = "Area Map";
                worldMapButton.gameObject.SetActive(true);
                if (noAreaMapText != null)
                    noAreaMapText.gameObject.SetActive(false);
                // Move close button to the right
                if (closeButton != null)
                    closeButton.GetComponent<RectTransform>().anchoredPosition = new Vector2(100f, -340f);
            }
            else if (!showingWorldMap)
            {
                // Showing area map - show toggle button to switch to world map
                toggleButtonText.text = "World Map";
                worldMapButton.gameObject.SetActive(true);
                if (noAreaMapText != null)
                    noAreaMapText.gameObject.SetActive(false);
                // Move close button to the right
                if (closeButton != null)
                    closeButton.GetComponent<RectTransform>().anchoredPosition = new Vector2(100f, -340f);
            }
            else
            {
                // No area map available, showing world map - hide toggle button, show message
                worldMapButton.gameObject.SetActive(false);
                if (noAreaMapText != null)
                    noAreaMapText.gameObject.SetActive(true);
                // Center the close button since toggle is hidden
                if (closeButton != null)
                    closeButton.GetComponent<RectTransform>().anchoredPosition = new Vector2(0f, -340f);
            }
        }

        private void LoadAreaMap(string mapName)
        {
            if (areaMapImage == null) return;

            Texture2D tex = GetMapTexture(mapName);
            if (tex != null)
            {
                areaMapImage.texture = tex;
            }
        }

        private Texture2D GetMapTexture(string mapName)
        {
            if (mapCache.ContainsKey(mapName))
                return mapCache[mapName];

            string path = Path.Combine(mapAssetsPath, mapName + ".png");

            try
            {
                if (!File.Exists(path))
                {
                    Debug.LogWarning($"[BetterMinimap] Map file not found: {path}");
                    return null;
                }

                byte[] data = File.ReadAllBytes(path);
                Texture2D tex = new Texture2D(1, 1, TextureFormat.RGBA32, false);
                ImageConversion.LoadImage(tex, data);
                mapCache[mapName] = tex;
                return tex;
            }
            catch (System.Exception ex)
            {
                Debug.LogWarning($"[BetterMinimap] Failed to load map {mapName}: {ex.Message}");
                return null;
            }
        }

        #endregion
    }

    /// <summary>
    /// Harmony patches to intercept the game's default map toggle behavior.
    /// </summary>
    public static class BetterMinimapPatches
    {
        /// <summary>
        /// Completely replace the game's M key handling.
        /// The game's native M key toggles minimap size and position - we want M to show our area map overlay instead.
        /// </summary>
        [HarmonyPatch(typeof(Minimap), "Update")]
        public class Minimap_Update_Patch
        {
            private static bool Prefix(Minimap __instance)
            {
                // Handle the map visibility logic (first part of original Update)
                if (GameData.UseMap)
                {
                    if (!__instance.MapPar.gameObject.activeSelf)
                    {
                        __instance.MapPar.gameObject.SetActive(true);
                        __instance.MapCam.gameObject.SetActive(true);
                    }
                }
                else if (__instance.MapPar.gameObject.activeSelf)
                {
                    __instance.MapPar.gameObject.SetActive(false);
                    __instance.MapCam.gameObject.SetActive(false);
                }

                // Block the M key handling entirely - we handle it in BetterMinimapController
                // The original method would toggle minimap size and position, which we don't want
                // Return false to skip the rest of the original Update method
                return false;
            }
        }
    }
}
