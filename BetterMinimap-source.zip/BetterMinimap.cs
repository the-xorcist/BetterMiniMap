using System.Collections.Generic;
using System.IO;
using HarmonyLib;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using BepInEx;

namespace BetterMinimap
{
    /// <summary>
    /// MonoBehaviour controller for BetterMinimap.
    /// Handles:
    /// - Always-moveable minimap (no edit mode required)
    /// - Resize toggle between small and large
    /// - Position/size persistence
    /// - Area map overlay with scene maps
    /// </summary>
    public class BetterMinimapController : MonoBehaviour
    {
        public static BetterMinimapController Instance { get; private set; }

        // Minimap references (found at runtime)
        private Minimap minimapComponent;
        private RectTransform minimapParent;
        private GameObject dragHandle;

        // Drag state
        private bool isDragging;
        private Vector2 dragOffset;
        private bool initialized;

        // Area Map state
        private bool areaMapOpen;
        private GameObject areaMapCanvas;
        private RawImage areaMapImage;
        private Button worldMapButton;
        private Button closeButton;
        private Text toggleButtonText;
        private bool showingWorldMap;

        // Area map textures
        private string mapAssetsPath;
        private Dictionary<string, Texture2D> mapCache = new Dictionary<string, Texture2D>();
        private List<string> mapAreas = new List<string>
        {
            "Azure", "Azynthi", "AzynthiClear", "Blight", "Brake", "Braxonian",
            "Duskenlight", "FernallaField", "Hidden", "Loomingwood",
            "Malaroth", "Ripper", "SaltedStrand", "ShiveringStep", "ShiveringTomb",
            "Silkengrass", "Soluna", "Stowaway", "Tutorial", "Vitheo",
            "Windwashed"
        };

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            mapAssetsPath = Path.Combine(Paths.PluginPath, "BetterMinimap", "Assets");
            SceneManager.sceneLoaded += OnSceneLoaded;
            Debug.Log("BetterMinimapController: Initialized");
        }

        private void OnDestroy()
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
        }

        private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
        {
            // Reset references - they may be stale after scene load
            initialized = false;
            minimapComponent = null;
            minimapParent = null;

            if (scene.name == "Menu" || scene.name == "LoadScene")
                return;

            // Close area map on scene change
            if (areaMapOpen)
                CloseAreaMap();
        }

        private void FindMinimapReferences()
        {
            if (initialized) return;

            // Find the Minimap component
            minimapComponent = FindObjectOfType<Minimap>();
            if (minimapComponent == null) return;

            minimapParent = minimapComponent.MapPar;
            if (minimapParent == null) return;

            // Apply saved position
            Vector2 savedPos = new Vector2(Plugin.MinimapPosX.Value, Plugin.MinimapPosY.Value);
            minimapParent.localPosition = savedPos;

            // Apply saved size mode
            if (Plugin.MinimapIsBig.Value)
            {
                SetMinimapSize(true);
            }

            // Create drag handle
            CreateDragHandle();

            initialized = true;
            Debug.Log("BetterMinimapController: Minimap references found");
        }

        private void CreateDragHandle()
        {
            if (dragHandle != null || minimapComponent == null || minimapParent == null) return;

            // Create a diamond-shaped drag handle centered below the minimap
            dragHandle = new GameObject("DragHandle");
            dragHandle.transform.SetParent(minimapParent, false);

            RectTransform handleRect = dragHandle.AddComponent<RectTransform>();
            // Position centered below the minimap
            float currentSize = minimapComponent.Mask.sizeDelta.x;
            handleRect.anchorMin = new Vector2(0.5f, 0.5f);
            handleRect.anchorMax = new Vector2(0.5f, 0.5f);
            handleRect.pivot = new Vector2(0.5f, 0.5f);
            // Place just below the minimap circle
            handleRect.anchoredPosition = new Vector2(0f, -(currentSize / 2f) - 15f);
            handleRect.sizeDelta = new Vector2(16f, 16f);

            Image handleImage = dragHandle.AddComponent<Image>();
            handleImage.color = new Color32(108, 194, 255, 255); // Same blue as BetterStatsPage

            // Rotate 45 degrees to make it a diamond
            dragHandle.transform.rotation = Quaternion.Euler(0f, 0f, 45f);

            // Add EventTrigger for drag events
            EventTrigger et = dragHandle.AddComponent<EventTrigger>();
            AddDragEvents(et);
        }

        private void AddDragEvents(EventTrigger et)
        {
            // Begin drag
            EventTrigger.Entry beginDrag = new EventTrigger.Entry { eventID = EventTriggerType.BeginDrag };
            beginDrag.callback.AddListener((data) =>
            {
                isDragging = true;
                GameData.DraggingUIElement = true;
                PointerEventData pData = (PointerEventData)data;
                Canvas canvas = minimapParent.GetComponentInParent<Canvas>();
                if (canvas != null)
                {
                    Vector2 localPoint;
                    RectTransformUtility.ScreenPointToLocalPointInRectangle(
                        canvas.transform as RectTransform, pData.position, null, out localPoint);
                    dragOffset = (Vector2)minimapParent.localPosition - localPoint;
                }
            });
            et.triggers.Add(beginDrag);

            // Drag
            EventTrigger.Entry drag = new EventTrigger.Entry { eventID = EventTriggerType.Drag };
            drag.callback.AddListener((data) =>
            {
                if (isDragging)
                {
                    PointerEventData pData = (PointerEventData)data;
                    Canvas canvas = minimapParent.GetComponentInParent<Canvas>();
                    if (canvas != null)
                    {
                        Vector2 localPoint;
                        RectTransformUtility.ScreenPointToLocalPointInRectangle(
                            canvas.transform as RectTransform, pData.position, null, out localPoint);
                        minimapParent.localPosition = localPoint + dragOffset;
                    }
                }
            });
            et.triggers.Add(drag);

            // End drag
            EventTrigger.Entry endDrag = new EventTrigger.Entry { eventID = EventTriggerType.EndDrag };
            endDrag.callback.AddListener((data) =>
            {
                isDragging = false;
                GameData.DraggingUIElement = false;
                SaveMinimapPosition();
            });
            et.triggers.Add(endDrag);
        }

        private void UpdateDragHandlePosition()
        {
            if (dragHandle == null || minimapComponent == null) return;
            RectTransform handleRect = dragHandle.GetComponent<RectTransform>();
            float currentSize = minimapComponent.Mask.sizeDelta.x;
            handleRect.anchoredPosition = new Vector2(0f, -(currentSize / 2f) - 15f);
        }

        private void ToggleMinimapSize()
        {
            bool newSize = !Plugin.MinimapIsBig.Value;
            SetMinimapSize(newSize);
            Plugin.MinimapIsBig.Value = newSize;
            Plugin.Instance.SaveConfig();
            UpdateDragHandlePosition();
        }

        private void SetMinimapSize(bool big)
        {
            if (minimapComponent == null) return;

            // Use reflection or direct field access based on Minimap.cs analysis
            if (big)
            {
                minimapComponent.MapCam.orthographicSize = 250f;
                minimapComponent.Mask.sizeDelta = new Vector2(750f, 750f);
                minimapComponent.CircleTrim.sizeDelta = new Vector2(772f, 772f);
                minimapComponent.Buttons.transform.localPosition = new Vector2(
                    minimapComponent.Buttons.transform.localPosition.x, -360f);
                if (minimapComponent.UIDrag != null)
                    minimapComponent.UIDrag.GetComponent<Image>().enabled = false;
            }
            else
            {
                minimapComponent.MapCam.orthographicSize = 100f;
                minimapComponent.Mask.sizeDelta = new Vector2(250f, 250f);
                minimapComponent.CircleTrim.sizeDelta = new Vector2(257f, 256f);
                minimapComponent.Buttons.transform.localPosition = new Vector2(
                    minimapComponent.Buttons.transform.localPosition.x, -100f);
                if (minimapComponent.UIDrag != null)
                    minimapComponent.UIDrag.GetComponent<Image>().enabled = true;
            }
        }

        private void Update()
        {
            // Skip if in menus
            string sceneName = SceneManager.GetActiveScene().name;
            if (sceneName == "Menu" || sceneName == "LoadScene") return;
            if (GameData.PlayerControl == null) return;

            // Find minimap references if not yet found
            FindMinimapReferences();

            // Handle area map key
            if (Input.GetKeyDown(Plugin.AreaMapKey.Value) && !GameData.PlayerTyping)
            {
                if (areaMapOpen)
                    CloseAreaMap();
                else
                    OpenAreaMap();
            }

            // Handle right-click on minimap buttons to toggle size
            HandleMinimapRightClick();
        }

        private void HandleMinimapRightClick()
        {
            if (minimapComponent == null || minimapComponent.Buttons == null) return;

            // Check for right-click
            if (Input.GetMouseButtonDown(1))
            {
                Vector2 mousePos = Input.mousePosition;

                // Check if over any minimap button (the + and - zoom buttons)
                Button[] buttons = minimapComponent.Buttons.GetComponentsInChildren<Button>();
                foreach (Button btn in buttons)
                {
                    RectTransform btnRect = btn.GetComponent<RectTransform>();
                    if (RectTransformUtility.RectangleContainsScreenPoint(btnRect, mousePos))
                    {
                        // Right-clicked on a minimap button - toggle size
                        ToggleMinimapSize();
                        return;
                    }
                }
            }
        }

        private void SaveMinimapPosition()
        {
            if (minimapParent == null) return;
            Plugin.MinimapPosX.Value = minimapParent.localPosition.x;
            Plugin.MinimapPosY.Value = minimapParent.localPosition.y;
            Plugin.Instance.SaveConfig();
        }

        #region Area Map

        private void OpenAreaMap()
        {
            if (areaMapOpen) return;

            string sceneName = SceneManager.GetActiveScene().name;
            CreateAreaMapUI();

            // Load appropriate map
            if (mapAreas.Contains(sceneName))
            {
                LoadAreaMap(sceneName);
                showingWorldMap = false;
            }
            else
            {
                LoadAreaMap("MapRoutes");
                showingWorldMap = true;
            }

            UpdateToggleButtonText();
            areaMapOpen = true;
        }

        private void CloseAreaMap()
        {
            if (areaMapCanvas != null)
            {
                Destroy(areaMapCanvas);
                areaMapCanvas = null;
            }
            areaMapOpen = false;
            GameData.DraggingUIElement = false; // Allow game input again
        }

        private void CreateAreaMapUI()
        {
            if (areaMapCanvas != null) return;

            // Block game input while area map is open
            GameData.DraggingUIElement = true;

            // Create canvas
            areaMapCanvas = new GameObject("AreaMapCanvas");
            Canvas canvas = areaMapCanvas.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 100;
            areaMapCanvas.AddComponent<CanvasScaler>();
            areaMapCanvas.AddComponent<GraphicRaycaster>();

            // Create fullscreen blocker to catch all clicks
            GameObject blocker = new GameObject("Blocker");
            blocker.transform.SetParent(areaMapCanvas.transform, false);
            RectTransform blockerRect = blocker.AddComponent<RectTransform>();
            blockerRect.anchorMin = Vector2.zero;
            blockerRect.anchorMax = Vector2.one;
            blockerRect.offsetMin = Vector2.zero;
            blockerRect.offsetMax = Vector2.zero;
            Image blockerImg = blocker.AddComponent<Image>();
            blockerImg.color = new Color(0f, 0f, 0f, 0.5f); // Semi-transparent dark background

            // Create centered square panel (use fixed size like the game's world map)
            GameObject panel = new GameObject("Panel");
            panel.transform.SetParent(areaMapCanvas.transform, false);
            RectTransform panelRect = panel.AddComponent<RectTransform>();
            panelRect.anchorMin = new Vector2(0.5f, 0.5f);
            panelRect.anchorMax = new Vector2(0.5f, 0.5f);
            panelRect.pivot = new Vector2(0.5f, 0.5f);
            // Use a fixed square size similar to the game's world map (approximately 700x700)
            panelRect.sizeDelta = new Vector2(700f, 750f);

            Image panelBg = panel.AddComponent<Image>();
            panelBg.color = new Color(0.05f, 0.1f, 0.15f, 0.95f);

            // Create map image - maintain square aspect ratio
            GameObject mapObj = new GameObject("MapImage");
            mapObj.transform.SetParent(panel.transform, false);
            RectTransform mapRect = mapObj.AddComponent<RectTransform>();
            mapRect.anchorMin = new Vector2(0.5f, 0.55f);
            mapRect.anchorMax = new Vector2(0.5f, 0.55f);
            mapRect.pivot = new Vector2(0.5f, 0.5f);
            // Square map image
            mapRect.sizeDelta = new Vector2(650f, 650f);

            areaMapImage = mapObj.AddComponent<RawImage>();
            areaMapImage.color = Color.white;

            // Create toggle button (World Map / Area Map)
            CreateAreaMapButton(panel.transform, "ToggleBtn", "World Map",
                new Vector2(-100f, -340f), new Vector2(150f, 35f),
                ToggleAreaWorldMap, out worldMapButton, out toggleButtonText);

            // Create close button
            Text closeText;
            CreateAreaMapButton(panel.transform, "CloseBtn", "Close",
                new Vector2(100f, -340f), new Vector2(150f, 35f),
                CloseAreaMap, out closeButton, out closeText);
        }

        private void CreateAreaMapButton(Transform parent, string name, string text,
            Vector2 position, Vector2 size, UnityEngine.Events.UnityAction onClick,
            out Button btn, out Text txtComp)
        {
            GameObject btnObj = new GameObject(name);
            btnObj.transform.SetParent(parent, false);

            RectTransform btnRect = btnObj.AddComponent<RectTransform>();
            btnRect.anchorMin = new Vector2(0.5f, 0.5f);
            btnRect.anchorMax = new Vector2(0.5f, 0.5f);
            btnRect.pivot = new Vector2(0.5f, 0.5f);
            btnRect.anchoredPosition = position;
            btnRect.sizeDelta = size;

            Image btnImage = btnObj.AddComponent<Image>();
            btnImage.color = new Color(0.2f, 0.4f, 0.6f, 1f);

            btn = btnObj.AddComponent<Button>();
            btn.onClick.AddListener(onClick);

            // Button text
            GameObject textObj = new GameObject("Text");
            textObj.transform.SetParent(btnObj.transform, false);
            RectTransform textRect = textObj.AddComponent<RectTransform>();
            textRect.anchorMin = Vector2.zero;
            textRect.anchorMax = Vector2.one;
            textRect.offsetMin = Vector2.zero;
            textRect.offsetMax = Vector2.zero;

            txtComp = textObj.AddComponent<Text>();
            txtComp.text = text;
            txtComp.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            txtComp.fontSize = 20;
            txtComp.alignment = TextAnchor.MiddleCenter;
            txtComp.color = Color.white;
            txtComp.raycastTarget = false;
        }

        private void ToggleAreaWorldMap()
        {
            string sceneName = SceneManager.GetActiveScene().name;

            if (showingWorldMap)
            {
                // Switch to area map if available
                if (mapAreas.Contains(sceneName))
                {
                    LoadAreaMap(sceneName);
                    showingWorldMap = false;
                }
            }
            else
            {
                // Switch to world map
                LoadAreaMap("MapRoutes");
                showingWorldMap = true;
            }

            UpdateToggleButtonText();
        }

        private void UpdateToggleButtonText()
        {
            if (toggleButtonText == null) return;

            string sceneName = SceneManager.GetActiveScene().name;
            bool hasAreaMap = mapAreas.Contains(sceneName);

            if (showingWorldMap && hasAreaMap)
            {
                toggleButtonText.text = "Area Map";
                worldMapButton.interactable = true;
            }
            else if (!showingWorldMap)
            {
                toggleButtonText.text = "World Map";
                worldMapButton.interactable = true;
            }
            else
            {
                // No area map available, showing world map
                toggleButtonText.text = "World Map";
                worldMapButton.interactable = false;
            }
        }

        private void LoadAreaMap(string mapName)
        {
            if (areaMapImage == null) return;

            Texture2D tex = GetMapTexture(mapName);
            if (tex != null)
            {
                areaMapImage.texture = tex;
            }
        }

        private Texture2D GetMapTexture(string mapName)
        {
            if (mapCache.ContainsKey(mapName))
                return mapCache[mapName];

            string path = Path.Combine(mapAssetsPath, mapName + ".png");

            try
            {
                if (!File.Exists(path))
                {
                    Debug.LogWarning($"[BetterMinimap] Map file not found: {path}");
                    return null;
                }

                byte[] data = File.ReadAllBytes(path);
                Texture2D tex = new Texture2D(1, 1, TextureFormat.RGBA32, false);
                ImageConversion.LoadImage(tex, data);
                mapCache[mapName] = tex;
                return tex;
            }
            catch (System.Exception ex)
            {
                Debug.LogWarning($"[BetterMinimap] Failed to load map {mapName}: {ex.Message}");
                return null;
            }
        }

        #endregion
    }

    /// <summary>
    /// Harmony patches to intercept the game's default map toggle behavior.
    /// </summary>
    public static class BetterMinimapPatches
    {
        /// <summary>
        /// Prevent the game's default M key handler from running when we want to show our area map.
        /// </summary>
        [HarmonyPatch(typeof(Minimap), "Update")]
        public class Minimap_Update_Patch
        {
            private static bool Prefix(Minimap __instance)
            {
                // Let the base update run, but we handle M key ourselves
                // The base game uses InputManager.Map which may conflict
                // For now, let's just let both run - ours shows area map, theirs toggles size
                return true;
            }
        }
    }
}
