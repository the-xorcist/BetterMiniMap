using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;

namespace BetterMinimap
{
    [BepInPlugin("the-xorcist.betterminimap", "Better Minimap", "1.0.3")]
    public class Plugin : BaseUnityPlugin
    {
        public static Plugin Instance { get; private set; }
        public new ManualLogSource Logger => base.Logger;

        // Minimap position/size persistence
        public static ConfigEntry<float> MinimapPosX;
        public static ConfigEntry<float> MinimapPosY;
        public static ConfigEntry<bool> MinimapIsBig;

        // Area Map key binding
        public static ConfigEntry<KeyCode> AreaMapKey;

        // Area Map position persistence
        public static ConfigEntry<float> AreaMapPosX;
        public static ConfigEntry<float> AreaMapPosY;

        // Lock North setting
        public static ConfigEntry<bool> LockNorth;

        private void Awake()
        {
            Instance = this;
            Logger.LogInfo("Better Minimap: Initializing...");

            // Initialize configuration
            MinimapPosX = Config.Bind("Minimap", "PositionX", 700f,
                "Saved X position of the minimap");
            MinimapPosY = Config.Bind("Minimap", "PositionY", 433f,
                "Saved Y position of the minimap");
            MinimapIsBig = Config.Bind("Minimap", "IsBigMap", false,
                "Whether the minimap is in large mode");
            AreaMapKey = Config.Bind("Controls", "AreaMapKey", KeyCode.M,
                "Key to open the area map overlay");
            AreaMapPosX = Config.Bind("AreaMap", "PositionX", float.NaN,
                "Saved X position of the area map panel (NaN = centered)");
            AreaMapPosY = Config.Bind("AreaMap", "PositionY", float.NaN,
                "Saved Y position of the area map panel (NaN = centered)");
            LockNorth = Config.Bind("Minimap", "LockNorth", false,
                "Whether the minimap should be locked to true north");

            // Create controller GameObject using proven pattern
            GameObject controllerGO = new GameObject("BetterMinimapController");
            controllerGO.transform.SetParent(null);
            controllerGO.hideFlags = HideFlags.HideAndDontSave;
            controllerGO.AddComponent<BetterMinimapController>();
            Object.DontDestroyOnLoad(controllerGO);

            // Apply Harmony patches
            Harmony harmony = new Harmony("the-xorcist.betterminimap");
            harmony.PatchAll();

            Logger.LogInfo("Better Minimap: Initialized successfully.");
        }

        public void SaveConfig()
        {
            Config.Save();
        }
    }
}

