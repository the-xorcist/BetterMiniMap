using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;

namespace BetterMinimap
{
    [BepInPlugin("the-xorcist.betterminimap", "Better Minimap", "1.0.0")]
    public class Plugin : BaseUnityPlugin
    {
        public static Plugin Instance { get; private set; }
        public new ManualLogSource Logger => base.Logger;

        // Minimap position/size persistence
        public static ConfigEntry<float> MinimapPosX;
        public static ConfigEntry<float> MinimapPosY;
        public static ConfigEntry<bool> MinimapIsBig;

        // Area Map key binding
        public static ConfigEntry<KeyCode> AreaMapKey;

        private void Awake()
        {
            Instance = this;
            Logger.LogInfo("Better Minimap: Initializing...");

            // Initialize configuration
            MinimapPosX = Config.Bind("Minimap", "PositionX", 700f,
                "Saved X position of the minimap");
            MinimapPosY = Config.Bind("Minimap", "PositionY", 433f,
                "Saved Y position of the minimap");
            MinimapIsBig = Config.Bind("Minimap", "IsBigMap", false,
                "Whether the minimap is in large mode");
            AreaMapKey = Config.Bind("Controls", "AreaMapKey", KeyCode.M,
                "Key to open the area map overlay");

            // Create controller GameObject using proven pattern
            GameObject controllerGO = new GameObject("BetterMinimapController");
            controllerGO.transform.SetParent(null);
            controllerGO.hideFlags = HideFlags.HideAndDontSave;
            controllerGO.AddComponent<BetterMinimapController>();
            Object.DontDestroyOnLoad(controllerGO);

            // Apply Harmony patches
            Harmony harmony = new Harmony("the-xorcist.betterminimap");
            harmony.PatchAll();

            Logger.LogInfo("Better Minimap: Initialized successfully.");
        }

        public void SaveConfig()
        {
            Config.Save();
        }
    }
}

